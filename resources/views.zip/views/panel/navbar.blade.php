<header class="px-4 py-2 shadow bg-white">
    <div class="flex justify-between">
        <div class="flex items-center">
            {{-- <button data-menu class="p-4 -ml-3 focus:outline-none md:hidden" type="button">
                <svg class="fill-current w-6 h-6" viewBox="0 -21 384 384">
                    <path d="M362.668 0H21.332C9.578 0 0 9.578 0 21.332V64c0 11.754 9.578 21.332 21.332 21.332h341.336C374.422 85.332 384 75.754 384 64V21.332C384 9.578 374.422 0 362.668 0zm0 0M362.668 128H21.332C9.578 128 0 137.578 0 149.332V192c0 11.754 9.578 21.332 21.332 21.332h341.336c11.754 0 21.332-9.578 21.332-21.332v-42.668c0-11.754-9.578-21.332-21.332-21.332zm0 0M362.668 256H21.332C9.578 256 0 265.578 0 277.332V320c0 11.754 9.578 21.332 21.332 21.332h341.336c11.754 0 21.332-9.578 21.332-21.332v-42.668c0-11.754-9.578-21.332-21.332-21.332zm0 0" />
                </svg>
            </button> --}}

            {{-- <div class="hidden md:block relative">
                <input type="text" placeholder="Search" class="h-auto pl-10 py-2 bg-gray-200 text-sm border border-gray-500 rounded-full focus:outline-none focus:bg-white w-64">
            </div> --}}
        </div>

        <div class="flex items-center space-x-4">
            <button data-messages class="p-3 focus:outline-none hover:bg-gray-200 rounded-md">
                <svg class="fill-current w-5" viewBox="0 0 512 512">
                    <path d="M339.392 258.624L512 367.744V144.896zM0 144.896v222.848l172.608-109.12zM480 80H32C16.032 80 3.36 91.904.96 107.232L256 275.264l255.04-168.032C508.64 91.904 495.968 80 480 80zM310.08 277.952l-45.28 29.824a15.983 15.983 0 01-8.8 2.624c-3.072 0-6.112-.864-8.8-2.624l-45.28-29.856L1.024 404.992C3.488 420.192 16.096 432 32 432h448c15.904 0 28.512-11.808 30.976-27.008L310.08 277.952z" />
                </svg>
            </button>
            <button data-notifications class="p-3 focus:outline-none hover:bg-gray-200 rounded-md">
                <svg class="fill-current w-5" viewBox="-21 0 512 512">
                    <path d="M213.344 512c38.636 0 70.957-27.543 78.379-64H134.965c7.426 36.457 39.746 64 78.379 64zm0 0M362.934 255.98c-.086 0-.172.02-.258.02-82.324 0-149.332-66.988-149.332-149.332 0-22.637 5.207-44.035 14.273-63.277-4.695-.446-9.453-.723-14.273-.723-82.473 0-149.332 66.855-149.332 149.332v59.477c0 42.218-18.496 82.07-50.946 109.503C2.25 370.22-2.55 384.937 1.332 399.297c4.523 16.703 21.035 27.371 38.36 27.371H386.89c18.175 0 35.308-11.777 38.996-29.59 2.86-13.781-2.047-27.543-12.735-36.523-31.02-26.004-48.96-64.215-50.218-104.575zm0 0" />
                    <path style="fill: red;" d="M469.344 106.668c0 58.91-47.754 106.664-106.668 106.664-58.91 0-106.664-47.754-106.664-106.664C256.012 47.758 303.766 0 362.676 0c58.914 0 106.668 47.758 106.668 106.668zm0 0" />
                </svg>
            </button>

            <div class="relative" x-data="{ open: false }">
                <button @click="open = !open" class="flex items-center p-2 focus:outline-none">
                    <img src="https://images.unsplash.com/photo-1544005313-94ddf0286df2?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=100&h=100&q=80" alt="Profile" class="h-8 w-8 rounded-full">
                    <span class="ml-4 text-sm hidden md:inline-block">Cairocoders</span>
                    <svg class="fill-current w-3 ml-4" viewBox="0 0 407.437 407.437">
                        <path d="M386.258 91.567l-182.54 181.945L21.179 91.567 0 112.815 203.718 315.87l203.719-203.055z" />
                    </svg>
                </button>
                <div x-show="open" @click.away="open = false" class="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg z-20">
                    <ul>
                        <li class="px-4 py-3 border-b hover:bg-gray-200"><a href="#">My Profile</a></li>
                        <li class="px-4 py-3 border-b hover:bg-gray-200"><a href="#">Settings</a></li>
                        <li class="px-4 py-3 hover:bg-gray-200"><a href="#">Log out</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</header>
