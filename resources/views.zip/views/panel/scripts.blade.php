
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
{{-- @vite('resources/css/app.css') --}}
<script src="https://cdn.jsdelivr.net/gh/alpinejs/alpine@v2.8.2/dist/alpine.min.js"></script>
