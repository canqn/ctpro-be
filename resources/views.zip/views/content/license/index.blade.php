@extends('layouts.app')

@section('title', 'Danh sách test')

@section('contents')
<div>
    <h1>Test</h1>
</div>
@endsection
